# A Little Game written in C++

## Compile & Build
```bash
make
```

## Run 
```bash
./bin/SurvivEE
```